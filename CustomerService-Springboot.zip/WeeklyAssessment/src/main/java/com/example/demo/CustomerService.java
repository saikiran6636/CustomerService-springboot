package com.example.demo;



import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    private final CustomerRepository repo;

    public CustomerService(CustomerRepository repo) {
        this.repo = repo;
    }

    // Salary automation
    private double getSalary(String desig) {
        return switch (desig.toLowerCase()) {
            case "programmer" -> 20000;
            case "manager" -> 25000;
            case "tester" -> 15000;
            default -> 0;
        };
    }

    // CREATE
    public Customer createCustomer(String name, int age, String designation) {

        // name validation (max 2 spaces)
        int spaces = name.length() - name.replace(" ", "").length();
        if (spaces > 2)
            throw new RuntimeException("Name must contain at most 2 spaces");

        // age validation
        if (age < 20 || age > 60)
            throw new RuntimeException("Age must be between 20 and 60");

        double salary = getSalary(designation);
        if (salary == 0)
            throw new RuntimeException("Invalid designation");

        return repo.save(new Customer(name, age, designation, salary));
    }

    // DISPLAY
    public List<Customer> getAllCustomers() {
        return repo.findAll();
    }
     
    public Customer getCustomer(String name) {
    	return repo.findByNameIgnoreCase(name).orElseThrow(()-> new RuntimeException("Employee not found"));
    }

    // RAISE SALARY
    public Customer raiseSalary(String name, int percent) {

        if (percent < 1 || percent > 10)
            throw new RuntimeException("Percentage must be 1–10");

        Customer emp = repo.findByNameIgnoreCase(name)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        emp.setSalary(emp.getSalary() + emp.getSalary() * percent / 100);
        return repo.save(emp);
    }
    //update employee
    public Customer updateCustomer(Customer emp) {

    	Customer existing = repo.findByNameIgnoreCase(emp.getName())
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        existing.setAge(emp.getAge());
        existing.setDesignation(emp.getDesignation());

        double salary;
        switch (emp.getDesignation().toLowerCase()) {
            case "programmer": salary = 20000; break;
            case "manager": salary = 25000; break;
            case "tester": salary = 15000; break;
            default: throw new RuntimeException("Invalid designation");
        }
        existing.setSalary(salary);

        return repo.save(existing);
    }
    //delete employee
    public void deleteCustomer(String name) {

    	Customer emp = repo.findByNameIgnoreCase(name)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        repo.delete(emp);
    }

}

