package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {
    @Autowired
    private final CustomerService service;

    public CustomerController(CustomerService service) {
        this.service = service;
    }

    // CREATE EMPLOYEE
    @PostMapping("/create")
    public Customer createCustomer(
            @RequestBody Customer c) {

        return service.createCustomer(c.getName(), c.getAge(), c.getDesignation());
    }

    // DISPLAY ALL
    @GetMapping("/all")
    public List<Customer> getAllCustomers() {
        return service.getAllCustomers();
    }

    @GetMapping("/{name}")
    public Customer getCustomer(@PathVariable String name) {
    	return service.getCustomer(name);
    }
    
    // RAISE SALARY
    @PutMapping("/raise")
    public Customer raiseSalary(@RequestBody  RaiseSalaryRequest r) {

        return service.raiseSalary(r.getName(), r.getPercent());
    }
    
    @PutMapping("/update")
    public Customer updateCustomer(@RequestBody Customer c) {
        return service.updateCustomer(c);
    }
    
    @DeleteMapping("delete/{name}")
    public String deleteCustomer(@PathVariable String name) {
        service.deleteCustomer(name);
        return "Employee deleted successfully";
    }
}
